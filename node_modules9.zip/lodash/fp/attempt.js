var convert = require('./convert'),
    func = convert('attempt', require('../attempt'));

func.placeholder = require('./placeholder');
module.exports = func;
