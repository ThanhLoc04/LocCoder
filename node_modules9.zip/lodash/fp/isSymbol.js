var convert = require('./convert'),
    func = convert('isSymbol', require('../isSymbol'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
