var convert = require('./convert'),
    func = convert('subtract', require('../subtract'));

func.placeholder = require('./placeholder');
module.exports = func;
