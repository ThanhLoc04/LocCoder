declare function encodeUtf8 (input: string): ArrayBuffer
export = encodeUtf8
