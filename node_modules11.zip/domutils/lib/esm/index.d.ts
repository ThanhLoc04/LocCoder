export * from "./stringify.js";
export * from "./traversal.js";
export * from "./manipulation.js";
export * from "./querying.js";
export * from "./legacy.js";
export * from "./helpers.js";
export * from "./feeds.js";
/** @deprecated Use these methods from `domhandler` directly. */
export { isTag, isCDATA, isText, isComment, isDocument, hasChildren, } from "domhandler";
//# sourceMappingURL=index.d.ts.map