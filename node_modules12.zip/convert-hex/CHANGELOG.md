0.1.0 / 2013-11-20
------------------
* changed package name from `cryptocoin-convert-string` to `convert-string`.
* removed AMD support

0.0.1 / 2013-11-03
------------------
* initial release