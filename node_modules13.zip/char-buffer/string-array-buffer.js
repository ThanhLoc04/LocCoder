module.exports = require('./lib/string-array-buffer').default;
