module.exports = require('./lib/typed-array-buffer').default;
