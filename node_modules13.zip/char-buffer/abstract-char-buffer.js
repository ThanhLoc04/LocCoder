module.exports = require('./lib/abstract-char-buffer').default;
