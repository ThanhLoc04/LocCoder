module.exports = require('./lib/string-buffer').default;
