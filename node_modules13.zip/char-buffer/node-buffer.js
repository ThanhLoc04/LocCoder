module.exports = require('./lib/node-buffer').default;
