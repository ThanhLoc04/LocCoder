
0.3.1 / 2016-01-14
==================

  * add MIT LICENSE file (#23, @kasicka)
  * preserve chaining after redundant style-method calls (#19, @drewblaisdell)
  * package: add "license" field (#16, @BenjaminTsai)

0.3.0 / 2014-05-09
==================

  * package: remove "test" script and "devDependencies"
  * package: remove "engines" section
  * pacakge: remove "bin" section
  * package: beautify
  * examples: remove `starwars` example (#15)
  * Documented goto, horizontalAbsolute, and eraseLine methods in README.md (#12, @Jammerwoch)
  * add `.jshintrc` file

< 0.3.0
=======

  * Prehistoric
