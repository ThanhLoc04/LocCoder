
var vows = require('vows')
var should = require('should')
var Audit = require('../lib/audit')

var validateNewAudit = {
    'new Audit': {
        topic:new Audit(),
        'has async method':function(topic) {
            topic.should.have.property('async')
            topic.async.should.be.a('function')
        },
        'has sync method':function(topic) {
            topic.should.have.property('sync')
            topic.sync.should.be.a('function')
        },
        'has run method':function(topic) {
            topic.should.have.property('run')
            topic.run.should.be.a('function')
        },
        'has default iterations 1000':function(topic) {
            topic.should.have.property('iters')
            topic.iters.should.equal(1000)
        },
        'has default pause 100':function(topic) {
            topic.should.have.property('pause')
            topic.pause.should.equal(100)
        }
    }
}

var options = {
    'new Audit({iterations:100, pause:200})': {
        topic:new Audit({iterations:100, pause:200}),
        'has iterations 100':function(topic) {
            topic.should.have.property('iters') 
            topic.iters.should.equal(100)
        },
        'has pause 200':function(topic) {
            topic.should.have.property('pause') 
            topic.pause.should.equal(200)
        }
    }
}

var chaining = {
    'async': {
        topic:function() {
            var audit = new Audit()
            var res = audit.async(function() { })
            this.callback(null, res)
        },
        'returns itself for chaining':function(topic) {
            topic.should.be.an.instanceOf(Audit)
        }
    },
    'sync': {
        topic:function() {
            var audit = new Audit()
            var res = audit.sync(function() { })
            this.callback(null, res)
        },
        'returns itself for chaining':function(topic) {
            topic.should.be.an.instanceOf(Audit)
        }
    }
}

var async = {
    '#on(auditing)': {
        topic:function() {
            var audit = new Audit()
            var self = this

            audit.on('auditing', function(res) {
                return self.callback(null, res)
            })

            function nFunc(next) { return next() }

            audit
            .async('myname', nFunc)
            .run()
        },
        'should return name of audit':function(topic) {
            topic.should.exist
            topic.should.equal('myname')
        }
    },
    '#on(auditcomplete)': {
        topic:function() {
            var audit = new Audit()
            var self = this
            audit.on('auditcomplete', function(res) {
                return self.callback(null, res)
            })
            function nFunc(next) { return next() }
            audit.async('myname', nFunc).run()
        },
        'should return stats for this audit':function(topic) {
            topic.should.exist

            topic.should.have.property('name', 'myname')
            topic.should.have.property('elapsed')
            topic.should.have.property('iterations')
            topic.should.have.property('opsPerSecond')
            topic.should.have.property('mean')
            topic.should.have.property('median')
            topic.should.have.property('mode')
            topic.should.have.property('max')
            topic.should.have.property('min')

            topic.name.should.be.a('string')
            topic.elapsed.should.be.a('string')
            topic.iterations.should.be.a('number')
            topic.opsPerSecond.should.be.a('number')
            topic.mean.should.be.a('string')
            topic.median.should.be.a('string')

            topic.mode.should.be.an.instanceOf(Array)
            topic.mode.should.have.length(2)
            topic.max.should.be.an.instanceOf(Array)
            topic.max.should.be.an.instanceOf(Array)
            topic.min.should.have.length(2)
            topic.min.should.have.length(2)

        }
    },
    '#on(complete)': {
        topic:function() {
            var audit = new Audit()
            var self = this

            audit.on('complete', function(res) {
                return self.callback(null, res)
            })

            function nFunc(next) { return next() }

            audit
            .async('one', nFunc)
            .async('two', nFunc)
            .async('three', nFunc)
            .run()
        },
        'returns stats object':function(topic) {
            topic.should.exist
            topic.should.have.property('one')
            topic.should.have.property('two')
            topic.should.have.property('three')

            topic.one.should.have.property('name', 'one')
            topic.one.should.have.property('elapsed')
            topic.one.should.have.property('iterations')
            topic.one.should.have.property('opsPerSecond')
            topic.one.should.have.property('mean')
            topic.one.should.have.property('median')
            topic.one.should.have.property('mode')
            topic.one.should.have.property('max')
            topic.one.should.have.property('min')

            topic.one.name.should.be.a('string')
            topic.one.elapsed.should.be.a('string')
            topic.one.iterations.should.be.a('number')
            topic.one.opsPerSecond.should.be.a('number')
            topic.one.mean.should.be.a('string')
            topic.one.median.should.be.a('string')

            topic.one.mode.should.be.an.instanceOf(Array)
            topic.one.mode.should.have.length(2)
            topic.one.max.should.be.an.instanceOf(Array)
            topic.one.max.should.be.an.instanceOf(Array)
            topic.one.min.should.have.length(2)
            topic.one.min.should.have.length(2)


            topic.two.should.have.property('name', 'two')
            topic.two.should.have.property('elapsed')
            topic.two.should.have.property('iterations')
            topic.two.should.have.property('opsPerSecond')
            topic.two.should.have.property('mean')
            topic.two.should.have.property('median')
            topic.two.should.have.property('mode')
            topic.two.should.have.property('max')
            topic.two.should.have.property('min')

            topic.two.name.should.be.a('string')
            topic.two.elapsed.should.be.a('string')
            topic.two.iterations.should.be.a('number')
            topic.two.opsPerSecond.should.be.a('number')
            topic.two.mean.should.be.a('string')
            topic.two.median.should.be.a('string')

            topic.two.mode.should.be.an.instanceOf(Array)
            topic.two.mode.should.have.length(2)
            topic.two.max.should.be.an.instanceOf(Array)
            topic.two.max.should.be.an.instanceOf(Array)
            topic.two.min.should.have.length(2)
            topic.two.min.should.have.length(2)

            topic.three.should.have.property('name', 'three')
            topic.three.should.have.property('elapsed')
            topic.three.should.have.property('iterations')
            topic.three.should.have.property('opsPerSecond')
            topic.three.should.have.property('mean')
            topic.three.should.have.property('median')
            topic.three.should.have.property('mode')
            topic.three.should.have.property('max')
            topic.three.should.have.property('min')

            topic.three.name.should.be.a('string')
            topic.three.elapsed.should.be.a('string')
            topic.three.iterations.should.be.a('number')
            topic.three.opsPerSecond.should.be.a('number')
            topic.three.mean.should.be.a('string')
            topic.three.median.should.be.a('string')

            topic.three.mode.should.be.an.instanceOf(Array)
            topic.three.mode.should.have.length(2)
            topic.three.max.should.be.an.instanceOf(Array)
            topic.three.max.should.be.an.instanceOf(Array)
            topic.three.min.should.have.length(2)
            topic.three.min.should.have.length(2)

        }
    }
}

var sync = {
    '#on(auditing)': {
        topic:function() {
            var audit = new Audit()
            var self = this

            audit.on('auditing', function(res) {
                return self.callback(null, res)
            })

            function nFunc() { return 1 }

            audit
            .sync('myname', nFunc)
            .run()
        },
        'should return name of audit':function(topic) {
            topic.should.exist
            topic.should.equal('myname')
        }
    },
    '#on(auditcomplete)': {
        topic:function() {
            var audit = new Audit()
            var self = this
            audit.on('auditcomplete', function(res) {
                return self.callback(null, res)
            })
            function nFunc() { return 1 }
            audit.sync('myname', nFunc).run()
        },
        'should return stats for this audit':function(topic) {
            topic.should.exist

            topic.should.have.property('name', 'myname')
            topic.should.have.property('elapsed')
            topic.should.have.property('iterations')
            topic.should.have.property('opsPerSecond')
            topic.should.have.property('mean')
            topic.should.have.property('median')
            topic.should.have.property('mode')
            topic.should.have.property('max')
            topic.should.have.property('min')

            topic.name.should.be.a('string')
            topic.elapsed.should.be.a('string')
            topic.iterations.should.be.a('number')
            topic.opsPerSecond.should.be.a('number')
            topic.mean.should.be.a('string')
            topic.median.should.be.a('string')

            topic.mode.should.be.an.instanceOf(Array)
            topic.mode.should.have.length(2)
            topic.max.should.be.an.instanceOf(Array)
            topic.max.should.be.an.instanceOf(Array)
            topic.min.should.have.length(2)
            topic.min.should.have.length(2)

        }
    },
    '#on(complete)': {
        topic:function() {
            var audit = new Audit()
            var self = this

            audit.on('complete', function(res) {
                return self.callback(null, res)
            })

            function nFunc() { return 1 }

            audit
            .sync('one', nFunc)
            .sync('two', nFunc)
            .sync('three', nFunc)
            .run()
        },
        'returns stats object':function(topic) {
            topic.should.exist
            topic.should.have.property('one')
            topic.should.have.property('two')
            topic.should.have.property('three')

            topic.one.should.have.property('name', 'one')
            topic.one.should.have.property('elapsed')
            topic.one.should.have.property('iterations')
            topic.one.should.have.property('opsPerSecond')
            topic.one.should.have.property('mean')
            topic.one.should.have.property('median')
            topic.one.should.have.property('mode')
            topic.one.should.have.property('max')
            topic.one.should.have.property('min')

            topic.one.name.should.be.a('string')
            topic.one.elapsed.should.be.a('string')
            topic.one.iterations.should.be.a('number')
            topic.one.opsPerSecond.should.be.a('number')
            topic.one.mean.should.be.a('string')
            topic.one.median.should.be.a('string')

            topic.one.mode.should.be.an.instanceOf(Array)
            topic.one.mode.should.have.length(2)
            topic.one.max.should.be.an.instanceOf(Array)
            topic.one.max.should.be.an.instanceOf(Array)
            topic.one.min.should.have.length(2)
            topic.one.min.should.have.length(2)

            topic.two.should.have.property('name', 'two')
            topic.two.should.have.property('elapsed')
            topic.two.should.have.property('iterations')
            topic.two.should.have.property('opsPerSecond')
            topic.two.should.have.property('mean')
            topic.two.should.have.property('median')
            topic.two.should.have.property('mode')
            topic.two.should.have.property('max')
            topic.two.should.have.property('min')

            topic.two.name.should.be.a('string')
            topic.two.elapsed.should.be.a('string')
            topic.two.iterations.should.be.a('number')
            topic.two.opsPerSecond.should.be.a('number')
            topic.two.mean.should.be.a('string')
            topic.two.median.should.be.a('string')

            topic.two.mode.should.be.an.instanceOf(Array)
            topic.two.mode.should.have.length(2)
            topic.two.max.should.be.an.instanceOf(Array)
            topic.two.max.should.be.an.instanceOf(Array)
            topic.two.min.should.have.length(2)
            topic.two.min.should.have.length(2)

            topic.three.should.have.property('name', 'three')
            topic.three.should.have.property('elapsed')
            topic.three.should.have.property('iterations')
            topic.three.should.have.property('opsPerSecond')
            topic.three.should.have.property('mean')
            topic.three.should.have.property('median')
            topic.three.should.have.property('mode')
            topic.three.should.have.property('max')
            topic.three.should.have.property('min')

            topic.three.name.should.be.a('string')
            topic.three.elapsed.should.be.a('string')
            topic.three.iterations.should.be.a('number')
            topic.three.opsPerSecond.should.be.a('number')
            topic.three.mean.should.be.a('string')
            topic.three.median.should.be.a('string')

            topic.three.mode.should.be.an.instanceOf(Array)
            topic.three.mode.should.have.length(2)
            topic.three.max.should.be.an.instanceOf(Array)
            topic.three.max.should.be.an.instanceOf(Array)
            topic.three.min.should.have.length(2)
            topic.three.min.should.have.length(2)

        }
    }
}
vows
.describe('Validate New Audit')
.addBatch(validateNewAudit)
.export(module)

vows
.describe('Options')
.addBatch(options)
.export(module)


vows
.describe('Chaining')
.addBatch(chaining)
.export(module)

vows
.describe('Async')
.addBatch(async)
.export(module)

vows.describe('Sync')
.addBatch(sync)
.export(module)
